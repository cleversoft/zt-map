drop table `#__ztmap_items`;
drop table `#__ztmap_sitemap`;